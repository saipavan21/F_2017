#!/usr/bin/env python
# ECBM E4040 Fall 2017 Assignment 2
# This script is intended for task 5 Kaggle competition. Use it however you want.