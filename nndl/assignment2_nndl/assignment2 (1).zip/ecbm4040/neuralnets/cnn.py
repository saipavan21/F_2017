#!/usr/bin/env/ python
# ECBM E4040 Fall 2017 Assignment 2
# TensorFlow CNN

import tensorflow as tf
import numpy as np
import time

####################################
# TODO: Build your own LeNet model #
####################################


def my_LeNet(input_x, input_y):
    raise NotImplementedError

####################################
#        End of your code          #
####################################

##########################################
# TODO: Build your own training function #
##########################################


def my_training(X_train, y_train, X_val, y_val):

    raise NotImplementedError
##########################################
#            End of your code            #
##########################################


def my_training_task4():
    # TODO: Copy my_training function, make modifications so that it uses your
    # data generator from task 4 to train.
    raise NotImplementedError
